from pathlib import Path
import sys,json,time
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R.parent/'20261022-051129-character-logistics-restoration-0f2e71/capture-tool-research/jinxiangw-source/src'))
from renderdoc_mcp.integration import LiveBridgeClient
c=LiveBridgeClient(timeout=300);pid=int((R/'replay.pid').read_text())
for attempt in range(30):
    window=next((w['window_id'] for w in c.list_windows()['data']['windows'] if w['pid']==pid),None)
    if window:break
    time.sleep(.5)
assert window
def call(method,params,name):
    result=c.call(method,params,window_id=window)
    (R/(name+'-receipt.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
    assert result.get('ok'),str(result)[:800]
    print(name,flush=True);return result
try:
    call('open_capture',dict(path=str(R.parent/'20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc'),wait=120),'positive-hair-open')
    for x,y in [(1268,212),(1309,218),(1258,215)]:
        key=f'positive-hair-{x}-{y}'
        call('export_pixel_history',dict(rid='ResourceId::141976',x=x,y=1439-y,eid_min=950,eid_max=950,dest=str(R/(key+'-history.json'))),key+'-history')
        d=json.loads((R/(key+'-history.json')).read_text());passed=[m for m in d['modifications'] if not any(m.get(f,False) for f in ('depthTestFailed','shaderDiscarded','backfaceCulled','stencilTestFailed'))]
        assert passed,key
        call('export_shader_debug_trace',dict(eid=950,x=x,y=1439-y,primitive=passed[-1]['primitiveID'],dest=str(R/(key+'-trace.json')),max_steps=20000),key+'-trace')
finally:call('close_capture',{},'positive-hair-close')
