from pathlib import Path
import json
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;R8=R.parent/'20261023-105023-character-composite-contribution-diagnosis-acb8e5'
word=np.fromfile(R8/'after-hair.bin',dtype='<u4').reshape(1440,2560)[::-1]
channels=[]
for shift,bits in [(0,6),(11,6),(22,5)]:
    v=(word>>shift)&((1<<(bits+5))-1);e=v>>bits;m=v&((1<<bits)-1)
    assert not np.any(e==31)
    channels.append(np.where(e==0,m.astype(float)*2**(-14-bits),(1+m/(1<<bits))*np.exp2(e.astype(float)-15)))
source=np.stack(channels,axis=-1)
mask=np.asarray(Image.open(R8/'native-hair-visible-mask.png').convert('L'))>0
candidate=np.asarray(Image.open(R/'sparse/frames/frame_000000.png').convert('RGB'))/255
linear=np.where(candidate<=.04045,candidate/12.92,((candidate+.055)/1.055)**2.4)*4
delta=np.abs(linear-source)
report={'schemaVersion':1,'stage':'source-event-950-vs-engine-beauty-before-grading','maskPixels':int(mask.sum()),'exposure':-2,'sourceFormat':'R11G11B10_FLOAT','linearMeanAbsoluteError':float(delta[mask].mean()),'linearMaximumError':float(delta[mask].max()),'linearErrorPercentiles':{str(p):float(np.percentile(delta[mask],p)) for p in [50,90,95,99]},'quarterExposureClippedPixels':int(np.any(candidate[mask]>=1,axis=1).sum())}
source_display=np.clip(source*.25,0,1);source_display=np.where(source_display<=.0031308,source_display*12.92,1.055*source_display**(1/2.4)-.055)
byte_delta=np.abs(np.rint(source_display*255).astype(int)-np.rint(candidate*255).astype(int));report['byteMeanAbsoluteError']=float(byte_delta[mask].mean());report['byteMaximumError']=int(byte_delta[mask].max())
ys,xs=np.where(mask);box=(int(xs.min())-5,int(ys.min())-5,int(xs.max())+6,int(ys.max())+6)
tiles=[Image.fromarray(np.uint8(np.rint(source_display*255))),Image.fromarray(np.uint8(np.rint(candidate*255))),Image.fromarray(np.uint8(np.clip(delta*255,0,255)))]
cropped=[t.crop(box) for t in tiles];strip=Image.new('RGB',(cropped[0].width*3,cropped[0].height))
for i,t in enumerate(cropped):strip.paste(t,(i*t.width,0))
strip.save(R/'visible-hair-source-candidate-error.png')
(R/'visible-hair-comparison.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
