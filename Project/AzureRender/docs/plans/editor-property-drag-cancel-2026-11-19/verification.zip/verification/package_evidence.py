import hashlib
import json
from pathlib import Path
import zipfile

run = Path(__file__).resolve().parent
root = Path('D:/Projects/FYP-worktrees/editor-interaction/Project/AzureRender')
destination = root / 'docs/plans/editor-property-drag-cancel-2026-11-19'
destination.mkdir(parents=True, exist_ok=True)
candidate = run / 'candidate/run-8d5a0d38'
baseline = run / 'baseline/run-4589e89e'
items = {}

def include(name, path):
    items[name] = path.read_bytes()

for name in ('verify_candidate.py', 'check_integration.py', 'package_evidence.py', 'build.log', 'cpu.log', 'gpu.log',
             'candidate-steps.json', 'candidate-executable.json', 'candidate.patch',
             'mainline-local.patch', 'integration-conflicts.json'):
    include('verification/' + name, run / name)
events = json.loads((baseline / 'exploration/edit/evidence.json').read_bytes())
hashes = [event['response']['value'] for event in events
          if event['op'] == 'query' and event['fields']['name'] == 'document.contentHash']
states = [json.loads(event['response']['value']) for event in events
          if event['op'] == 'query' and event['fields']['name'] == 'editor.workspace']
assert hashes[0] != hashes[-1]
failure = {'dispatch': 2236, 'expectedFailure': True,
    'assertion': 'Escape must restore original mixed values', 'source': 'baseline/evidence.json',
    'expectedContentHash': hashes[0], 'actualContentHash': hashes[-1],
    'expectedUndoCount': states[0]['undoCount'], 'actualUndoCount': states[-1]['undoCount']}
items['baseline/failure-summary.json'] = (json.dumps(failure, indent=2) + '\n').encode()
include('candidate/summary.json', candidate / 'summary.json')
for name, directory in (('baseline', baseline / 'exploration/edit'),
                        ('candidate/exploration/edit', candidate / 'exploration/edit'),
                        ('candidate/inspector/edit', candidate / 'inspector/edit'),
                        ('candidate/exploration/reopen', candidate / 'exploration/reopen'),
                        ('candidate/inspector/reopen', candidate / 'inspector/reopen')):
    for filename in ('evidence.json', 'runtime.json', 'stdout.log', 'stderr.log'):
        include(name + '/' + filename, directory / filename)
    for path in directory.glob('*.png'):
        include(name + '/' + path.name, path)
for workflow in ('exploration', 'inspector'):
    project = candidate / workflow / 'project'
    descriptor = json.loads((project / 'project.azureproject').read_bytes())
    level = project / 'assets' / descriptor['startupScene'].removeprefix('assets:/')
    include('candidate/' + workflow + '/saved-scene.json', level)
sources = ['src/editor/commands/EditService.cpp', 'src/editor/commands/EditService.hpp',
    'src/editor/commands/EditorOperations.cpp', 'src/editor/panels/InspectorPanel.cpp',
    'src/editor/properties/PropertyWidgets.cpp', 'tests/EditTransactionTests.cpp',
    'tools/test_editor_multi_properties.py']
for name in sources:
    include('source/' + name, root / name)
manifest = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(items.items())]
archive = destination / 'verification.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as package:
    for name, data in sorted(items.items()):
        package.writestr(name, data)
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for entry in manifest:
        assert hashlib.sha256(package.read(entry['path'])).hexdigest() == entry['sha256']
conflicts = json.loads((run / 'integration-conflicts.json').read_bytes())
summary = json.loads((candidate / 'summary.json').read_bytes())
assert len(summary['cases']) == 2 and all(case['passed'] for case in summary['cases'])
steps = json.loads((run / 'candidate-steps.json').read_bytes())
assert all(step['exitCode'] == 0 for step in steps)
result = {'unit': 'property-drag-cancel', 'productionBaseline': '5fccef930dcff848238a0d919cb5a139bde1372d',
    'fixtureBaseline': '32e56f97eafab23a90adba3cfc6bcb859868e434', 'configuration': 'Release',
    'baselineExecutableSha256': '75778c34da23ceb5387e6baf195cbdcc63a9fac8ae05c304156cc1d1fb2ea9ee',
    'candidateExecutableSha256': summary['executableSha256'],
    'dispatch': [{'id': 2236, 'expectedFailure': True, 'exitCode': 1}, {'id': 2237, 'exitCode': 0}],
    'checks': {'cancelAfterHeldDragThenRelease': True, 'originalMixedValues': True,
        'selectionAndContentHash': True, 'undoCountAndDirtyState': True, 'normalDragOneUndo': True,
        'preservedRedoExecutable': True, 'saveReopen': True, 'nonSelectedNodesUnchanged': True,
        'staleCancellationRejected': True, 'cpuPassed': 5},
    'cases': summary['cases'], 'sharedContract': conflicts, 'physicalInput': False,
    'archive': archive.name, 'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archiveBytes': archive.stat().st_size, 'files': manifest}
(destination / 'results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
(destination / '.gitattributes').write_text('results.json -text\nverification.zip -text\n', encoding='ascii', newline='\n')
print(json.dumps({'archiveBytes': result['archiveBytes'], 'archiveSha256': result['archiveSha256'],
    'resultsSha256': hashlib.sha256((destination / 'results.json').read_bytes()).hexdigest(), 'files': len(manifest)}))
