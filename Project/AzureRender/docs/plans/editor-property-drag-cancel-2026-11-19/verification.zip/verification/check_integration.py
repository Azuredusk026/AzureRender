import hashlib
import json
import os
from pathlib import Path
import subprocess

output = Path(__file__).resolve().parent
main = Path('D:/Projects/FYP')
work = Path('D:/Projects/FYP-worktrees/editor-interaction')
paths = ['Project/AzureRender/src/editor/EditorContext.hpp',
         'Project/AzureRender/src/editor/commands/EditService.cpp',
         'Project/AzureRender/src/editor/commands/EditTransaction.cpp']
changed = subprocess.check_output(['git', '-C', str(work), 'diff', '--name-only', 'HEAD', '--',
    'Project/AzureRender/src/editor']).decode().splitlines()

def git(repo, *args, env=None):
    return subprocess.check_output(['git', '-C', str(repo), *args], env=env)

def sha(value):
    return hashlib.sha256(value).hexdigest()

records = []
patches = []
for path in paths:
    committed = git(main, 'show', 'HEAD:' + path)
    actual = (main / path).read_bytes()
    canonical = actual.replace(b'\r\n', b'\n')
    dirty = canonical != committed.replace(b'\r\n', b'\n')
    patch = git(main, 'diff', '--no-ext-diff', '--no-textconv', 'HEAD', '--', path)
    if patch:
        patches.append(patch)
    records.append({'path': path, 'mainlineFileSha256': sha(actual),
        'mainlineHeadBlobSha256': sha(committed), 'contentDiffersAfterNewlineNormalization': dirty,
        'candidateTouchesFile': path in changed, 'mainlineDiffBytes': len(patch)})
patch = git(work, 'diff', '--binary', 'HEAD', '--', 'Project/AzureRender/src/editor')
(output / 'candidate.patch').write_bytes(patch)
(output / 'mainline-local.patch').write_bytes(b''.join(patches))
environment = dict(os.environ, GIT_INDEX_FILE=str(output / 'integration-check.index'))
git(main, 'read-tree', 'HEAD', env=environment)
if patches:
    subprocess.run(['git', '-C', str(main), 'apply', '--cached', str(output / 'mainline-local.patch')], env=environment, check=True)
result = subprocess.run(['git', '-C', str(main), 'apply', '--cached', '--check', str(output / 'candidate.patch')],
                        env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
receipt = {'mainline': git(main, 'rev-parse', 'HEAD').decode().strip(),
           'worktreeBase': git(work, 'rev-parse', 'HEAD').decode().strip(),
           'candidatePatchSha256': sha(patch), 'sharedFiles': records,
           'isolatedIndexApplyExitCode': result.returncode, 'isolatedIndexApplyOutput': result.stdout.decode(errors='replace'),
           'mainlineWorktreeModified': False}
(output / 'integration-conflicts.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
