import json
import os
from pathlib import Path
import subprocess
import sys

root = Path("D:/Projects/FYP-worktrees/editor-interaction/Project/AzureRender")
run = Path(__file__).resolve().parent
build = root / "build/ninja-msvc-release"
cmake = Path("D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe")
env = dict(os.environ)
env.setdefault("VULKAN_SDK", "D:/Tools/VulkanSDK/1.4.350.0")
env.setdefault("VCPKG_ROOT", "D:/Tools/vcpkg")
temp = run / "temp"
temp.mkdir(exist_ok=True)
env.update(TMP=str(temp), TEMP=str(temp))

commands = {
    "build": [root / "tools/msvc_env.bat", cmake, "--build", build, "--target", "AzureRender",
              "AzureEditTransactionTests", "AzureEditServiceTests", "AzurePropertyEditingTests",
              "AzureUiFoundationTests", "AzureEditorCreationTests", "-j", "3"],
    "cpu": [cmake.with_name("ctest.exe"), "--test-dir", build, "-R",
            r"^AzureEditor\.(EditTransaction|EditService|PropertyEditing|UiFoundation|Creation)$", "--output-on-failure"],
    "gpu": [sys.executable, "-B", root / "tools/test_editor_multi_properties.py", "--executable",
            build / "AzureRender.exe", "--output", run / "candidate"],
}
steps = []
for name, args in commands.items():
    command = list(map(str, args))
    with (run / (name + ".log")).open("wb") as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    steps.append({"name": name, "command": command, "exitCode": result.returncode})
    (run / "candidate-steps.json").write_text(json.dumps(steps, indent=2) + "\n", encoding="utf-8")
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
