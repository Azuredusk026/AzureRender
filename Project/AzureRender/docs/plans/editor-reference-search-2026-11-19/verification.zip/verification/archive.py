import hashlib
import json
from pathlib import Path
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

run = Path(__file__).resolve().parent
root = Path("D:/Projects/FYP-worktrees/editor-interaction/Project/AzureRender")
dest = root / "docs/plans/editor-reference-search-2026-11-19"
sources = [
    "src/editor/panels/CorePanels.hpp", "src/editor/panels/InspectorPanel.cpp",
    "src/ui/localization/Catalog.inc", "tools/test_editor_reference_search.py",
]
files = {}

def include(name, path):
    files[name] = path.read_bytes()

for name in ("baseline.log", "build.log", "cpu.log", "gpu.log", "candidate-steps.json",
             "verify_candidate.py", "archive.py"):
    include("verification/" + name, run / name)
for label in ("baseline", "candidate"):
    directory = run / label
    include(label + "/summary.json", directory / "summary.json")
    for workflow in ("exploration", "inspector"):
        case = directory / workflow
        for stage in ("edit", "reopen"):
            session = case / stage
            if not session.is_dir():
                continue
            for name in ("evidence.json", "runtime.json", "stdout.log", "stderr.log"):
                include(f"{label}/{workflow}/{stage}/{name}", session / name)
            for path in session.glob("reference-*.png"):
                include(f"{label}/{workflow}/{stage}/{path.name}", path)
        if label == "candidate":
            project = case / "project"
            startup = json.loads((project / "project.azureproject").read_bytes())["startupScene"]
            include(f"{label}/{workflow}/saved-scene.json", project / "assets" / startup.removeprefix("assets:/"))
            include(f"{label}/{workflow}/audio-sidecar.json", project / "assets/search-reference-sound.wav.azmeta")
for name in sources:
    include("source/" + name, root / name)
files["verification/production.patch"] = subprocess.check_output(
    ["git", "diff", "4e07fef", "--", *sources[:3]], cwd=root,
)

def sha(data):
    return hashlib.sha256(data).hexdigest()

baseline = json.loads(files["baseline/summary.json"])
candidate = json.loads(files["candidate/summary.json"])
steps = json.loads(files["verification/candidate-steps.json"])
assert baseline["executableSha256"] == "17e7aa390a32683e1287569615082acc41e0db6ed524c411bdc97a882628b04c"
assert [step["exitCode"] for step in steps] == [0, 0, 0]
assert {case["workflow"] for case in candidate["cases"]} == {"exploration", "inspector"}
assert all(case["passed"] for case in candidate["cases"])
assert b"100% tests passed, 0 tests failed out of 4" in files["verification/cpu.log"]
assert sha((root / "build/ninja-msvc-release/AzureRender.exe").read_bytes()) == candidate["executableSha256"]
dest.mkdir(parents=True, exist_ok=True)
archive = dest / "verification.zip"
with ZipFile(archive, "w", ZIP_DEFLATED) as package:
    for name, data in sorted(files.items()):
        package.writestr(name, data)
with ZipFile(archive) as package:
    assert package.testzip() is None
    assert all(package.read(name) == data for name, data in files.items())

result = {
    "productionBaseline": "4e07fef4845d7065374f3ecb0bfa090fa0d2c598",
    "configuration": "Release",
    "baselineExecutableSha256": baseline["executableSha256"],
    "candidateExecutableSha256": candidate["executableSha256"],
    "dispatch": [{"id": 2256, "purpose": "historical-input-and-screenshot", "exitCode": 0},
                 {"id": 2257, "purpose": "build-and-regression", "exitCode": 0}],
    "baselineFindings": ["search-lacks-focus", "empty-list-has-no-feedback", "search-persists-across-fields"],
    "cases": candidate["cases"],
    "cpuPassed": 4,
    "physicalInput": False,
    "archiveSha256": sha(archive.read_bytes()),
    "files": [{"path": name, "sha256": sha(data)} for name, data in sorted(files.items())],
}
(dest / ".gitattributes").write_text("results.json -text\nverification.zip -text\n", encoding="ascii", newline="\n")
receipt = dest / "results.json"
receipt.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"files": len(files), "archiveSha256": result["archiveSha256"],
                  "resultsSha256": sha(receipt.read_bytes()), "executableSha256": candidate["executableSha256"]}))
