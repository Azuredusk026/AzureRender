import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path("D:/Projects/FYP-worktrees/editor-interaction/Project/AzureRender")
run = Path(__file__).resolve().parent
executable = root / "build/ninja-msvc-release/AzureRender.exe"
source = "9baa14fb128f65b57d90da356c89f3c01c651b8d"
fingerprint = "e2cdfbab6e3a150e8659fe4ccd738184a4f1d8641ae8412a1167023775f917c4"
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root).decode().strip() == source
assert hashlib.sha256(executable.read_bytes()).hexdigest() == fingerprint
environment = dict(os.environ)
temp = run / "temp"
temp.mkdir(exist_ok=True)
environment.update(TMP=str(temp), TEMP=str(temp))
checks = {
    "reference-search": "test_editor_reference_search.py",
    "viewport-workflow": "test_editor_usability.py",
    "document-recovery": "test_editor_document_guard.py",
    "view-modes": "test_editor_view_modes.py",
}
receipt = {"source": source, "executableSha256": fingerprint, "configuration": "Release",
           "physicalInput": False, "checks": []}
for name, script in checks.items():
    command = [sys.executable, "-B", str(root / "tools" / script), "--executable",
               str(executable), "--output", str(run / name)]
    start = time.monotonic()
    with (run / (name + ".log")).open("wb") as log:
        result = subprocess.run(command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT)
    receipt["checks"].append({"name": name, "exitCode": result.returncode,
        "seconds": round(time.monotonic() - start, 3), "command": command})
    (run / "checks.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(name, result.returncode, flush=True)
assert hashlib.sha256(executable.read_bytes()).hexdigest() == fingerprint
raise SystemExit(any(check["exitCode"] for check in receipt["checks"]))
