import hashlib
import json
import os
from pathlib import Path
import subprocess

run = Path(__file__).resolve().parent
main = Path("D:/Projects/FYP")
editor = Path("D:/Projects/FYP-worktrees/editor-interaction")
scope = "Project/AzureRender/src"
candidate = "9baa14fb128f65b57d90da356c89f3c01c651b8d"
anchor = "5d4cf7d"

def git(path, *args, env=None):
    return subprocess.check_output(["git", "-C", str(path), *args], env=env)

head = git(main, "rev-parse", "HEAD").decode().strip()
paths = git(editor, "diff", "--name-only", anchor, candidate, "--", scope).decode().splitlines()
local = git(main, "diff", "--name-only", "HEAD", "--", *paths).decode().splitlines()
base_patch = git(editor, "diff", "--binary", anchor, candidate, "--", scope)
patch = run / "editor-implementation.patch"
patch.write_bytes(base_patch)
env = dict(os.environ, GIT_INDEX_FILE=str(run / "integration.index"))
git(main, "read-tree", head, env=env)
result = subprocess.run(["git", "-C", str(main), "apply", "--cached", "--check", str(patch)],
                        env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
receipt = {
    "mainline": head, "implementation": candidate, "sourceAnchor": anchor,
    "productionPaths": paths, "mainlineLocalMatches": local,
    "patchSha256": hashlib.sha256(base_patch).hexdigest(), "applyExitCode": result.returncode,
    "applyOutput": result.stdout.decode(errors="replace"),
}
(run / "integration.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt))
raise SystemExit(result.returncode)
