import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('D:/Projects/FYP-worktrees/editor-interaction/Project/AzureRender')
output = Path(__file__).resolve().parent
build = root / 'build/ninja-msvc-release'
cmake = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
ctest = str(Path(cmake).with_name('ctest.exe'))
environment = dict(os.environ)
environment.setdefault('VULKAN_SDK', 'D:/Tools/VulkanSDK/1.4.350.0')
environment.setdefault('VCPKG_ROOT', 'D:/Tools/vcpkg')
temp = output / 'temp'
temp.mkdir(exist_ok=True)
environment.update(TMP=str(temp), TEMP=str(temp))
steps = []

def run(name, command):
    with (output / (name + '.log')).open('w', encoding='utf-8') as stream:
        result = subprocess.run(command, cwd=root, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    steps.append({'name': name, 'command': list(map(str, command)), 'exitCode': result.returncode})
    (output / 'candidate-steps.json').write_text(json.dumps(steps, indent=2) + '\n', encoding='utf-8')
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

run('build', [str(root / 'tools/msvc_env.bat'), cmake, '--build', str(build), '--target',
    'AzureRender', 'AzureLocalizationTests', 'AzureUiFoundationTests', 'AzurePropertyEditingTests',
    'AzureEditorCreationTests', '-j', '3'])
run('cpu', [ctest, '--test-dir', str(build), '-R',
    '^AzureEditor\\.(UiFoundation|PropertyEditing|Creation)$|^AzureUi\\.Localization$', '--output-on-failure'])
run('gpu', [sys.executable, '-B', str(root / 'tools/test_editor_multi_properties.py'),
    '--executable', str(build / 'AzureRender.exe'), '--output', str(output / 'candidate')])
with (build / 'AzureRender.exe').open('rb') as stream:
    fingerprint = hashlib.file_digest(stream, 'sha256').hexdigest()
(output / 'candidate-executable.json').write_text(json.dumps({'sha256': fingerprint}) + '\n', encoding='utf-8')


