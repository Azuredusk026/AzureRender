import hashlib
import json
from pathlib import Path
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

run = Path(__file__).resolve().parent
root = Path("D:/Projects/FYP-worktrees/editor-interaction/Project/AzureRender")
destination = root / "docs/plans/editor-inspector-search-2026-11-19"
destination.mkdir(parents=True, exist_ok=True)
baseline, = (run / "baseline").glob("run-*")
candidate, = (run / "candidate").glob("run-*")
files = {}

def include(name, path):
    files[name] = path.read_bytes()

for name in ("baseline.log", "build.log", "cpu.log", "gpu.log", "candidate-steps.json",
             "verify_candidate.py", "archive.py"):
    include("verification/" + name, run / name)
include("candidate/summary.json", candidate / "summary.json")
for label, directory in (
    ("baseline/exploration", baseline / "exploration/edit"),
    ("candidate/exploration", candidate / "exploration/edit"),
    ("candidate/inspector", candidate / "inspector/edit"),
):
    for name in ("evidence.json", "runtime.json", "stdout.log", "stderr.log"):
        include(f"{label}/{name}", directory / name)
    for path in directory.glob("inspector-*-search-*.png"):
        include(f"{label}/{path.name}", path)
for workflow in ("exploration", "inspector"):
    for name in ("evidence.json", "runtime.json"):
        include(f"candidate/{workflow}/reopen/{name}", candidate / workflow / "reopen" / name)
for name in ("src/editor/panels/InspectorPanel.cpp", "src/ui/localization/Catalog.inc",
             "tools/test_editor_multi_properties.py"):
    include("source/" + name, root / name)
files["verification/production.patch"] = subprocess.check_output(
    ["git", "diff", "HEAD", "--", "src/editor/panels/InspectorPanel.cpp", "src/ui/localization/Catalog.inc"],
    cwd=root,
)

def sha(data):
    return hashlib.sha256(data).hexdigest()

summary = json.loads(files["candidate/summary.json"])
steps = json.loads(files["verification/candidate-steps.json"])
assert [step["exitCode"] for step in steps] == [0, 0, 0]
assert {case["workflow"] for case in summary["cases"]} == {"exploration", "inspector"}
assert all(case["passed"] and case["inspectorSearchAndClear"] for case in summary["cases"])
assert b"Field search must reveal a match inside a collapsed component" in files["verification/baseline.log"]
assert b"100% tests passed, 0 tests failed out of 4" in files["verification/cpu.log"]
assert sha((root / "build/ninja-msvc-release/AzureRender.exe").read_bytes()) == summary["executableSha256"]

archive = destination / "verification.zip"
with ZipFile(archive, "w", ZIP_DEFLATED) as package:
    for name, data in sorted(files.items()):
        package.writestr(name, data)
with ZipFile(archive) as package:
    assert package.testzip() is None
    assert all(package.read(name) == data for name, data in files.items())

result = {
    "baselineCommit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root).decode().strip(),
    "configuration": "Release",
    "baselineExecutableSha256": "096c283872c08d3f497098598c1eeb554f1b554a191f03bcbf8d0688bbe7c215",
    "candidateExecutableSha256": summary["executableSha256"],
    "dispatch": [{"id": 2245, "exitCode": 1, "expectedFailure": True}, {"id": 2246, "exitCode": 0}],
    "cases": summary["cases"],
    "cpuPassed": 4,
    "physicalInput": False,
    "archiveSha256": sha(archive.read_bytes()),
    "files": [{"path": name, "sha256": sha(data)} for name, data in sorted(files.items())],
}
(destination / ".gitattributes").write_text("results.json -text\nverification.zip -text\n", encoding="ascii", newline="\n")
receipt = destination / "results.json"
receipt.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"files": len(files), "archiveSha256": result["archiveSha256"],
                  "resultsSha256": sha(receipt.read_bytes()), "executableSha256": summary["executableSha256"]}))
